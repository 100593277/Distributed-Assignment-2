import java.io.*; 
import java.rmi.*;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;
import java.net.InetAddress;


public class FileClient{
   public static void main(String argv[]) {
	   
	   
	 
	      try {
	    	 String feature = null;
	   	     Scanner sc= new Scanner(System.in);
	   	     //automatically get host name
	         Registry reg = LocateRegistry.getRegistry(InetAddress.getLocalHost().getHostName()); 
	
	         FileInterface fi = (FileInterface) reg.lookup("FileServer");
	         
	         //Finding which feature is desired
	   	     System.out.println("Which feature do you want to use? \n");
	   	     
	   	     System.out.println("For calculating electricity bill, enter: \"elecBill\"" );
	   	     System.out.println("For finding if a year is a leap year, enter: \"leapYear\"" );
	   	   	 System.out.println("For finding the vowels in a word, enter: \"vowels\"" );
	   	   	 System.out.println("For some quick stress release riddles, enter: \"riddles\"" );
	   	   	 System.out.println("For finding the ASCII of a character, enter: \"ascii\"" );
	   	   	 
	   	   	 feature = sc.nextLine();
	   	   	 
	   	     
	         //If Function 1: electricity bill
	         if(feature.equalsIgnoreCase("elecBill")){
	        	System.out.println("What is the kilowatts used?");
	            elecBill(fi, sc.nextLine());
	         }//
	         
	         //If Function 2: leap Year
	         else if(feature.equalsIgnoreCase("leapYear")){
	         	System.out.println("What year do you want to check for leap year?");
	            leapYear(fi, sc.nextLine());
	         }//
	         //If Function 3: Vowels
	         else if(feature.equalsIgnoreCase("vowels"))
	         {
	        	System.out.println("Enter a word: ");
	     		vowels(fi,sc.nextLine());
	         }//
	         
	         //If Function 4: Riddles
	         else if(feature.equalsIgnoreCase("riddles"))
	         {
	        	double marks = 0;
	    		double total = 0;
	    		double percent = 0.0;
	    		
	    		//Riddle 1
	    		System.out.println("1) What common English word becomes shorter when you add two letters?");
	    		System.out.println(fi.riddle("1) What common English word becomes shorter when you add two letters?",sc.nextLine()));
	    			
	    		//Riddle 2
	    		System.out.println("2) I\'m tall when I\'m young, and I\'m short when I\'m old. What am I?");
	    		System.out.println(fi.riddle("2) I\'m tall when I\'m young, and I\'m short when I\'m old. What am I?",sc.nextLine())); 
	
	    		//Riddle 3
	    		System.out.println("3) What get\'s wet while drying?");
	    		System.out.println(fi.riddle("3) What get\'s wet while drying?",sc.nextLine())); 
	    		
	    		//No riddle remains, paramaters will not matter, will be used to print a final statement from riddle, "All scores tallied"
	    		System.out.println(fi.riddle("no riddle remains", "paramaters will not matter"));
	    		System.out.println(fi.riddleScore());
	    	 }//End of Trivia
	         
	       //If Function 5 ASCII Value: 
	       else if(feature.equalsIgnoreCase("ascii"))
	       {
	        	System.out.println("Enter a character: ");
	        	
	        	
	        	System.out.println(fi.ascii(sc.next().charAt(0)));
	       }//
	      }
	      
	      catch(Exception e) { 
	    	  System.err.println("FileServer exception: "+ e.getMessage());
	          e.printStackTrace();
	      }
         
      }
 
  //Function 1
   public static void elecBill (FileInterface fileInterface, String kwh) throws IOException 
   {
	   try
	   {
		   System.out.println("The Electricity bill will be: " + fileInterface.elecBill(Double.parseDouble(kwh)));
	   }
	   catch (Exception e)
	   {
		   System.out.println("Incorrect input!");
	   }
   }
 //Function 2
   public static void leapYear (FileInterface fileInterface, String year) throws IOException 
   {
	   try
	   { 
		   System.out.println("The year " +year+ " " + fileInterface.leapYear(Integer.parseInt(year)));
	   }
	   catch (Exception e)
	   {
		   System.out.println("Incorrect input!");
	   }
   }
 //Function 3
   public static void vowels (FileInterface fileInterface, String word) throws IOException 
   {
	   try
	   { 
		   System.out.println("For word \"" +word+ "\"\nThe Vowels Are: " + fileInterface.vowels((word)));
	   }
	   catch (Exception e) 
	   {
		   System.out.println("Incorrect input!");
	   }
   }

 //Function 5
   public static void ascii (FileInterface fileInterface, String ch) throws IOException 
   {
	   try
	   {
		   System.out.println("The ASCII value of " + ch + " will be: " + fileInterface.ascii(Integer.parseInt(String.valueOf(ch))));
	   }
	   catch (Exception e)
	   {
		   System.out.println("Incorrect input!");
	   }
   }

}