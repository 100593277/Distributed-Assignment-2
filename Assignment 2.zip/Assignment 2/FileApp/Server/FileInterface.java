import java.io.FileNotFoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;

public interface FileInterface extends Remote {
   public double elecBill(double kwh) throws RemoteException;
   public String leapYear (int year) throws RemoteException;
   public String vowels (String word) throws RemoteException;
   public int ascii(int ch) throws RemoteException;
   public String riddle(String riddle, String answer) throws RemoteException;
   public String riddleScore() throws RemoteException;


}