import java.io.*;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.rmi.*;
import java.rmi.server.RemoteServer;
import java.rmi.server.UnicastRemoteObject;
import java.util.Scanner;

public class FileImpl extends RemoteServer
  implements FileInterface {

   private String name;

   public FileImpl(String s) throws RemoteException {
      super();
      name = s;
   }
   //Function 1
   public double elecBill(double kwh) throws RemoteException
   {
	  try {	 
			double billpay=0;
		    if(kwh<100)
		        return billpay=kwh*1.20;
			else if(kwh<=300)
				return billpay=100*1.20+(kwh-100)*2;
			else if(kwh>300)
				return billpay=100*1.20+200*2+(kwh-300)*3;
	  }
	  catch (Exception e)
	  {
	  } 
	  return Double.parseDouble("Invalid input");
   }
   
   //Function 2
   public String leapYear (int year)
   {
	   try {
		   if(year!=0)
			{
			   if(year%400==0)
				   return (" is a leap year");
		       else  if(year%100==0)
		    	   return (" is not a leap year");
		       else if(year%4==0)                    
		    	   return (" is a leap year");
		       else 
		    	   return (" is not a leap year");
		 	}
			else
				 return ("Year 0 does not exist ");                       
		 	}
	   catch (Exception e)
		  {
		  } 
	   return ("Invalid input");
   }
   
   //Function 3
   public String vowels(String word)
   {
	   try {
		   char ch;
		   String vowels="\n";
		   int thereWasVowel=1;
		   
		   for(int k=0;k<word.length();k++)
			{
			   
				ch=word.charAt(k);	
				if(ch =='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u'||ch=='A'||ch=='E'
						 ||ch=='I'||ch=='O'||ch=='U')
				{
			            thereWasVowel=1;
			            vowels += String.valueOf(ch)+ "\n"; 		 
				  }
				 else
					 thereWasVowel=0;
			}

		   if(thereWasVowel==0)
				return ("There are no vowels in the word"); 
		   
		   return vowels;
	   }
	   catch (Exception e)
		{
		} 
	   return ("Invalid input");
	}
   
   //Function 4
   double marks = 0;
   double total = 0;
   double percent = 0.0;
   public String riddle(String riddle, String answer) throws RemoteException{
	   //Riddle 1
	   if(riddle.equalsIgnoreCase("1) What common English word becomes shorter when you add two letters?"))
		{
		   if(answer.equalsIgnoreCase("short"))
	   		{
			   marks++;
	   		   total++;
			   return ("Correct! ");		   
	   		}
		   else {
	   		   total++;
			   return("Incorrect, the answer is \"short\"");}
		}
	   //Riddle 2
	   else if(riddle.equalsIgnoreCase("2) I\'m tall when I\'m young, and I\'m short when I\'m old. What am I?"))
		{
		   if(answer.equalsIgnoreCase("candle"))
	   		{
			   
				marks++;
				total++;
				return ("Correct! ");
		   	} 
    		else {
    	   		total++;
    			return("Incorrect, the answer is \"Candle\"");}
		}
	   //Riddle 3
	   else if(riddle.equalsIgnoreCase("3) What get\'s wet while drying?"))
		{
		   if(answer.equalsIgnoreCase("towel"))
	   		{
	   		    total++;
	   			marks++;
			    return ("Correct! ");

	   		}
    		else {
        		total++;
    			return("Incorrect, the answer is \"Candle\"");}
		}
	   return "The answer has been tallied";
   }
   
   public String riddleScore () throws RemoteException
   {
	   percent = (marks/total) * 100;
	   return ("You have accumalated a final score of: " + String.format("%.2f", percent));
   }
   
   //Function 5
   public int ascii(int ch) throws RemoteException
   {
       // You can also cast char to int
       int castAscii = (int) ch;
       return castAscii;
   }
  
}
   